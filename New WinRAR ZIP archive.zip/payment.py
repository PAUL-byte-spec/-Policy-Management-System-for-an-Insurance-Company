from datetime import datetime, timedelta
class Payment:
    def __init__(self, amount, due_date, payment_method):
        self.amount = amount
        self.due_date = due_date
        self.payment_method = payment_method
        self.paid = False  # Flag indicating payment status

    def process(self):
        """Simulates processing the payment.

        This example doesn't connect to actual payment gateways.
        """
        if not self.paid:
            self.paid = True
            print(f"Payment of ${self.amount} received successfully.")
        else:
            print(f"Payment already processed on {self.due_date}.")

    def send_reminder(self):
        """Sends a reminder about the upcoming due date.

        This example assumes you have a mechanism to send reminders (e.g., email, SMS).
        """
        if not self.paid and self.due_date - datetime.date.today() <= timedelta(days=7):
            print(f"Reminder sent for payment of ${self.amount} due on {self.due_date}.")

    def calculate_penalty(self):
        """Calculates any late payment penalty based on the current date and due date.

        This example implements a simple penalty logic. You can customize it as needed.
        """
        if not self.paid and self.due_date < datetime.date.today():
            days_late = (datetime.date.today() - self.due_date).days
            penalty = self.amount * 0.01 * days_late  # 1% penalty per day late
            return penalty
        else:
            return 0

    def __str__(self):
        """Returns a string representation of the payment."""
        return f"Amount: ${self.amount}\nDue Date: {self.due_date}\nPayment Method: {self.payment_method}\nPaid: {self.paid}"

# Example Usage:
# payment = Payment(100, datetime.date(2024, 2, 8), "Credit Card")
# payment.process()
# print(payment.calculate_penalty())
# print(payment)
