class Product:
    def __init__(self, product_id, name, description, coverage_details, premium):
        self.product_id = product_id
        self.name = name
        self.description = description
        self.coverage_details = coverage_details
        self.premium = premium
        self.active = True  # Flag indicating product availability

    def create(self):
        """Creates a new product instance."""
        # Simulate product creation in your system (e.g., store in database)
        print(f"Product '{self.name}' (ID: {self.product_id}) created successfully.")

    def update(self, new_name, new_description, new_coverage_details, new_premium):
        """Updates existing product details."""
        if self.active:
            self.name = new_name
            self.description = new_description
            self.coverage_details = new_coverage_details
            self.premium = new_premium
            print(f"Product '{self.name}' (ID: {self.product_id}) updated successfully.")
        else:
            print(f"Product '{self.name}' (ID: {self.product_id}) is currently inactive and cannot be updated.")

    def remove(self):
        """Removes the product from the system."""
        if self.active:
            self.active = False
            print(f"Product '{self.name}' (ID: {self.product_id}) removed successfully.")
        else:
            print(f"Product '{self.name}' (ID: {self.product_id}) is already inactive.")

    def suspend(self):
        """Suspends the product from being offered to new policyholders."""
        if self.active:
            self.active = False
            print(f"Product '{self.name}' (ID: {self.product_id}) suspended.")
        else:
            print(f"Product '{self.name}' (ID: {self.product_id}) is already inactive.")

    def reactivate(self):
        """Reactivates the product for new policyholders."""
        if not self.active:
            self.active = True
            print(f"Product '{self.name}' (ID: {self.product_id}) reactivated.")
        else:
            print(f"Product '{self.name}' (ID: {self.product_id}) is already active.")

    def __str__(self):
        """Returns a string representation of the product."""
        return (
            f"ID: {self.product_id}\n"
            f"Name: {self.name}\n"
            f"Description: {self.description}\n"
            f"Coverage Details: {self.coverage_details}\n"
            f"Premium: ${self.premium}\n"
            f"Active: {self.active}"
        )
