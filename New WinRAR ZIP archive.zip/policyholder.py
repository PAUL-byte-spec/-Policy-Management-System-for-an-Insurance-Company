class Policyholder:
    def __init__(self, name, id_number, contact_info):
        self.name = name
        self.id_number = id_number
        self.contact_info = contact_info
        self.active = True
        self.policies = []  # List of associated policies

    def register(self, policy):
        """Registers a new policy for the policyholder.

        Args:
            policy: An instance of the Policy class.
        """
        if self.active:
            self.policies.append(policy)
            print(f"Policy registered successfully for {self.name}.")
        else:
            print(f"Policy cannot be registered for suspended policyholder: {self.name}.")

    def suspend(self):
        """Suspends the policyholder account."""
        if self.active:
            self.active = False
            print(f"Policyholder {self.name} suspended.")
        else:
            print(f"Policyholder {self.name} is already suspended.")

    def reactivate(self):
        """Reactivates the policyholder account."""
        if not self.active:
            self.active = True
            print(f"Policyholder {self.name} reactivated.")
        else:
            print(f"Policyholder {self.name} is already active.")

    def __str__(self):
        """Returns a string representation of the policyholder."""
        return f"Name: {self.name}\nID: {self.id_number}\nContact: {self.contact_info}\nActive: {self.active}"
