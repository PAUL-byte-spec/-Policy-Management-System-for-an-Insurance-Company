# main.py
from policyholder import Policyholder
from product import Product
from payment import Payment

# Create policyholders
policyholder1 = Policyholder(id=1, name="Agoroma Paul")
policyholder2 = Policyholder(id=2, name="Agoroma Julie")

# Create products
product1 = Product(id=101, name="Health Insurance", price=500)
product2 = Product(id=102, name="Car Insurance", price=300)

# Display initial details
print("Initial Details:")
print(policyholder1.display_details())
print(policyholder2.display_details())
print(product1.display_details())
print(product2.display_details())

# Process payment for policyholders
payment_processor = Payment()
print(payment_processor.process_payment(policyholder1, product1))
print(payment_processor.process_payment(policyholder2, product2))

# Display updated details after payment
print("\nDetails After Payment:")
print(policyholder1.display_details())
print(policyholder2.display_details())
print(product1.display_details())
print(product2.display_details())

